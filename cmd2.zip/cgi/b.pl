#!/usr/bin/perl
use strict;
use warnings;

# Get the command passed as argument
my $cmd = $ARGV[0];

# Check if the command is provided
if (!$cmd) {
    die "No command provided!\n";
}

# Execute the command and print the output
my $output = `$cmd 2>&1`;  # Capture both stdout and stderr
print $output;